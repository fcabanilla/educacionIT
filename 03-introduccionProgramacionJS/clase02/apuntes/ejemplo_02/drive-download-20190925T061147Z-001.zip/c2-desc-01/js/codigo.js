var edad = prompt("La edad del usuario es?")

if(edad >= 20){
alert("Usted tiene 20 años o más")}

else 

	 { alert("Usted tiene menos de 20 años, adios!")}



	