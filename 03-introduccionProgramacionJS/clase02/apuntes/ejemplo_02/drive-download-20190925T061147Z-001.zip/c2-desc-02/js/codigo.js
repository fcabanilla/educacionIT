var edad = prompt("La edad del usuario es?")

if(edad >= 20){
var nombre = prompt("Cual es su nombre?")
if(nombre == "Pedro")

	   { alert("Hola Pedro")   }

else 

	 { alert("Usted tiene 20 o más pero no es Pedro")}

                                                          }

else { alert("Usted tiene menos de 20 años, adios!")}



	