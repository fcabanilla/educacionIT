TODO
----

  * toolchain/extra software extension
  * mention git submodule
  * mention init signal handling?
  * better POSIX compliance
  * mention busybox applet preference option
  * less differences in scripts and docs, e.g. ``startup`` vs ``rcS``?
