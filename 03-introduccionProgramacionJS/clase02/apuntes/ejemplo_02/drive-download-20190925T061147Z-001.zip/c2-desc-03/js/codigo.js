var edad = prompt("La edad del usuario es?")

if (edad > 20) {
   alert("Usted tiene más de 20 años")
} else if (edad == 20 || edad > 15) {
   alert("Usted tiene entre 20 y 15 años")
} else {
   alert("Usted tiene 15 años o menos, adios!")
}


	