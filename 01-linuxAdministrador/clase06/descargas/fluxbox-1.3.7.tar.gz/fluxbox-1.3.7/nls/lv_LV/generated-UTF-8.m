$ codeset=UTF-8

$set 1 #Align

1 Apakšā Centrā
2 Apakšā pa Kreisi
3 Apakšā pa Labi
4 Horizontāls
6 Pa Kreisi Apakšā
7 Pa Kreisi Centrā
8 Pa Kreisi Augšā
11 Pa Labi Apakšā
12 Pa Labi Centrā
13 Pa Labi Augšā
14 Augšā Centrā
15 Augšā pa Kreisi
16 Augšā pa Labi
17 Vertikāls

$set 2 #BaseDisplay


$set 3 #Common

2 Auto paslēpt

$set 4 #Configmenu

2 Auto Pacelšana
4 Klikšķis, lai Fokusētu
7 Fokusēt Logu pie Darba vietas maiņas
8 Fokusēšanās Modelis
9 Fokusēt Jaunos Logus
10 Pilna Maksimizācija
11 Attēla Tonēšana
12 Necaurredzama Loga Pārvietošana
13 Pusnevīžīga Fokusēšana
14 Nevīžīga Fokusēšana
15 Pārvilkšana uz Darba vietu

$set 5 #Ewmh


$set 6 #FbTkError


$set 7 #Fluxbox


$set 8 #Gnome


$set 9 #Keys


$set 10 #Menu

3 Iziet
4 Ikonas
7 Novietošana
9 Restartēt

$set 11 #Remember


$set 12 #Screen

2 P: %4d x A: %4d
4 P: %04d x A: %04d

$set 13 #Slit

4 Šķēluma Virziens
7 Šķēluma Novietojums
8 Šķēlums

$set 14 #Toolbar

1 Rediģēt pašreizējās darba vietas nosaukumu
11 Rīkjosla

$set 15 #Window

1 Nenosaukts

$set 16 #Windowmenu

1 Aizvērt
2 Ikonificēt
4 Pazemināt
5 Maksimizēt
6 Pacelt
7 Sūtīt Uz ...
8 Ēnot
9 Stiķēt

$set 17 #Workspace

1 Darba vieta %d
2 Darba vietas
3 Jauna Darba vieta
4 Noņemt Pēdējo

$set 18 #fbsetroot

1 kļūda: jānosaka viens no: -solid, -mod, -gradient\n
3 -display <virkne>        displeja savienojums\n\
-mod <x> <y>             moduļa raksts\n\
-foreground, -fg <krāsa> moduļa priekšplāna krāsa\n\
-background, -bg <krāsa> moduļa fona krāsa\n\n\
-gradient <tekstūra>     gradienta tekstūra\n\
-from <krāsa>            pārejas sākuma krāsa\n\
-to <krāsa>              pārejas beigu krāsa\n\n\
-solid <krāsa>           viendabīga krāsa\n\n\
-help                    parādīt šo palīdzību un iziet\n

$set 19 #main

1 kļūda: '-display' nepieciešams arguments
11 kļūda: '-rc' nepieciešams arguments
13 Fluxbox %s: (c) %s Fluxbox Team\n\n\
-display <virkne>\t\tlietot displeja savienojumu.\n\
-screen <all|int,int,int>\trun on specified screens only.\n\
-no-slit\t\t\t\tdo not provide a slit.\n\
-no-toolbar\t\t\tdo not provide a toolbar.\n\
-rc <virkne>\t\t\tlietot citu resersu failu.\n\
-version\t\t\tparādīt versiju un iziet.\n\
-info\t\t\t\tdisplay some useful information.\n\
-list-commands\t\t\tlist all valid key commands.\n\
-sync\t\t\t\tsynchronize with X server for debugging.\n\
-log <filename>\t\t\tlog output to file.\n\
-help\t\t\t\tparādīt šo palīdzības tekstu un iziet.\n\n

